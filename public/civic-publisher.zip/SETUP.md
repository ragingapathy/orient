# Your region's Civic publisher

1. Create your own GitHub repository. Copy this starter's contents into its root, including the .github folder. Use git to upload workflows if the browser uploader hides that folder.
2. Replace live.config.json with the region config downloaded from Orient. Check the bounding box and the source agency's URL and attribution. No private map data is required.
3. If required, obtain a key from your state DOT/511 developer portal. Store it under repository Settings > Secrets and variables > Actions: OHGO_API_KEY (Ohio) or WZDX_API_KEY (other work-zone APIs). Config only names the secret; never insert its value. The workflow already passes those two secrets.
4. Enable Actions and run Live city data. Inspect source statuses. A successful job with a skipped source is not a connected feed. WZDx covers work zones. Ohio's separate adapter covers incidents and cameras; other agencies need their own adapter. Missing camera data is not zero cameras.
5. Connect https://raw.githubusercontent.com/OWNER/REPO/live-data/ in Orient > Civic > Set up sources. Test before saving. Roads refresh twice hourly; stale data stops being useful.

## Air quality
Built-in Orient observations use the public AirNow file without a personal API key. To publish your own, set civic.config.json sourceId and center [longitude, latitude]. Review AirNow's current Data Exchange Guidelines and complete their contact/agreement requirements. Only then set airnow and airnowGuidelinesAcknowledged to true. Run Air quality publisher manually. Connect https://raw.githubusercontent.com/OWNER/REPO/civic-data/civic.json. The app rejects observations older than its freshness limit; enable a twice-hourly schedule on air.yml if you want continuous publication (same cron pattern as live.yml). The manual workflow is off until you choose to run it.

Official sources:
- https://data.transportation.gov/Roadways-and-Bridges/Work-Zone-Data-Feed-Registry/69qe-yiui (includes API signup links by state)
- https://publicapi.ohgo.com/docs/registration
- https://docs.airnowapi.org/faq
- https://docs.airnowapi.org/docs/DataUseGuidelines.pdf

Keys stay in Actions secrets. Only normalized public civic records are published. No Orient contacts, notes, photos or pairing credentials belong in this repository.
